Installation
============

Install from Source
-------------------
Pyro supports 3.4+.  To setup, install `PyTorch <http://pytorch.org>`_ then run::

   pip install pyro-ppl

or install from source::

   git clone https://github.com/uber/pyro.git
   cd pyro
   python setup.py install
