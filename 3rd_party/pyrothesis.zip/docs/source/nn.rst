Neural Network
==============

The module `pyro.nn` provides implementations of neural network modules
that are useful in the context of deep probabilistic programming. None
of these modules is really part of the core language.

.. include:: pyro.nn.txt
