Generalised Linear Mixed Models
===============================

.. automodule:: pyro.contrib.glmm
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource