Getting Started
===============

 - `Install Pyro <http://pyro.ai#install>`_.

 - Learn the basic concepts of Pyro:
   `models <http://pyro.ai/examples/intro_part_i.html>`_ and
   `inference <http://pyro.ai/examples/svi_part_i.html>`_.

 - Dive in to other `tutorials <http://pyro.ai/examples>`_ and
   `examples <https://github.com/uber/pyro/tree/dev/examples>`_.
