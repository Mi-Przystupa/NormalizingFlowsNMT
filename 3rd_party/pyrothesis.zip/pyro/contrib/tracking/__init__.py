from pyro.contrib.tracking import assignment

__all__ = [
    "assignment",
]
