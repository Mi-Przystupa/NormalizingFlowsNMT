from pyro.contrib.bnn.hidden_layer import HiddenLayer

__all__ = [
    "HiddenLayer",
]
