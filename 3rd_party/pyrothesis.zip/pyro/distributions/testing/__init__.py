"""
This module contains distributions that are useful for testing new Pyro
inference algorithms.
"""
