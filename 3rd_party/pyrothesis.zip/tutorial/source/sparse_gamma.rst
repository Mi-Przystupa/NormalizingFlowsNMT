Sparse Gamma Deep Exponential Family
====================================

`View sparse_gamma_def.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/examples/sparse_gamma_def.py

__ github_

.. literalinclude:: ../../examples/sparse_gamma_def.py
    :language: python
