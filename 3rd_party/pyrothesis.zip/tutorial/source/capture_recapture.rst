Capture-Recapture Models (CJS Models)
=====================================

`View cjs.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/examples/capture_recapture/cjs.py

__ github_

.. literalinclude:: ../../examples/capture_recapture/cjs.py
    :language: python
