Sequential Monte Carlo Filtering
================================

`View smcfilter.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/examples/smcfilter.py

__ github_

.. literalinclude:: ../../examples/smcfilter.py
    :language: python
