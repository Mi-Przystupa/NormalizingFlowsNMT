Deep Kernel Learning
====================

`View sv-dkl.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/examples/contrib/gp/sv-dkl.py

__ github_

.. literalinclude:: ../../examples/contrib/gp/sv-dkl.py
    :language: python
