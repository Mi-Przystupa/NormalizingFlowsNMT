Latent Dirichlet Allocation
===========================

`View lda.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/examples/lda.py

__ github_

.. literalinclude:: ../../examples/lda.py
    :language: python
