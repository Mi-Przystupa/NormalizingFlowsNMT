Mini-Pyro
=========

`View pyro/contrib/minipyro.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/pyro/contrib/minipyro.py

__ github_

.. literalinclude:: ../../pyro/contrib/minipyro.py
    :language: python

Example use of mini-Pyro
------------------------

`View examples/minipyro.py on github`__

.. _example: https://github.com/uber/pyro/blob/dev/examples/minipyro.py

__ example_

.. literalinclude:: ../../examples/minipyro.py
    :language: python
