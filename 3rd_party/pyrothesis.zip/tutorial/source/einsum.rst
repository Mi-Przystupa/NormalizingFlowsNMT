Plated Einsum
=============

`View einsum.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/examples/einsum.py

__ github_

.. literalinclude:: ../../examples/einsum.py
    :language: python
