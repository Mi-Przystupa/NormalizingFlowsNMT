Hidden Markov Model
===================

`View hmm.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/examples/hmm.py

__ github_

.. literalinclude:: ../../examples/hmm.py
    :language: python
