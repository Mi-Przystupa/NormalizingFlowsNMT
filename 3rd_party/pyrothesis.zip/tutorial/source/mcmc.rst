Markov Chain Monte Carlo
========================

`View hmm.py on github`__

.. _github: https://github.com/uber/pyro/blob/dev/examples/eight_schools/mcmc.py

__ github_

.. literalinclude:: ../../examples/eight_schools/mcmc.py
    :language: python
