[http://pyro.ai/examples](http://pyro.ai/examples)
